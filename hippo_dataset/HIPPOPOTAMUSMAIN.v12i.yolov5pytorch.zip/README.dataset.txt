# HIPPOPOTAMUSMAIN > 2022-03-26 5:19pm
https://universe.roboflow.com/hypo/hippopotamusmain

Provided by a Roboflow user
License: CC BY 4.0


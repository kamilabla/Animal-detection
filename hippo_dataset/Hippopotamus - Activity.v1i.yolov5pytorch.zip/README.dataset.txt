# Hippopotamus & Activity > 2025-04-25 11:06pm
https://universe.roboflow.com/aomgandhi/hippopotamus-activity

Provided by a Roboflow user
License: MIT

